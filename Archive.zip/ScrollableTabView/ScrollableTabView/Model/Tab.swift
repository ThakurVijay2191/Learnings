//
//  Tab.swift
//  ScrollableTabView
//
//  Created by Nap Works on 12/11/23.
//

import SwiftUI

enum Tab: String, CaseIterable {
    case chats = "Chats"
    case calls = "Calls"
    case settings = "Settings"
    
    var systemImage: String {
        switch self {
        case .chats:
            return "bubble.left.and.bubble.right"
        case .calls:
            return "phone"
        case .settings:
            return "gear"
        }
    }
}
