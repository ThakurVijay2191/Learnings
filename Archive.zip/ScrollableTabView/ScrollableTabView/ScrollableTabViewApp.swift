//
//  ScrollableTabViewApp.swift
//  ScrollableTabView
//
//  Created by Nap Works on 12/11/23.
//

import SwiftUI

@main
struct ScrollableTabViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
