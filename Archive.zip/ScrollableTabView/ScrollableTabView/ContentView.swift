//
//  ContentView.swift
//  ScrollableTabView
//
//  Created by Nap Works on 12/11/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
