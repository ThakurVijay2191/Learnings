//
//  ContentView.swift
//  AppleWatchStoreUI
//
//  Created by Nap Works on 24/09/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
