//
//  AppleWatchStoreUIApp.swift
//  AppleWatchStoreUI
//
//  Created by Nap Works on 24/09/23.
//

import SwiftUI

@main
struct AppleWatchStoreUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
