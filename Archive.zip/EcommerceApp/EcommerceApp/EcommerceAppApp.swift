//
//  EcommerceAppApp.swift
//  EcommerceApp
//
//  Created by Nap Works on 30/09/23.
//

import SwiftUI

@main
struct EcommerceAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
