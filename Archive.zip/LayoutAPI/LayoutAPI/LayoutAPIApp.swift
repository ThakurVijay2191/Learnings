//
//  LayoutAPIApp.swift
//  LayoutAPI
//
//  Created by Nap Works on 11/11/23.
//

import SwiftUI

@main
struct LayoutAPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
