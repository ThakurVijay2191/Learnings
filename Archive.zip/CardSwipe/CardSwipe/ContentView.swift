//
//  ContentView.swift
//  CardSwipe
//
//  Created by Nap Works on 11/11/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
