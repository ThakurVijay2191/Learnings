//
//  CardSwipeApp.swift
//  CardSwipe
//
//  Created by Nap Works on 11/11/23.
//

import SwiftUI

@main
struct CardSwipeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
