//
//  InstagramDMSwipeApp.swift
//  InstagramDMSwipe
//
//  Created by Nap Works on 16/09/23.
//

import SwiftUI

@main
struct InstagramDMSwipeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
