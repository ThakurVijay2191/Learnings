//
//  CustomSegmentedPickerApp.swift
//  CustomSegmentedPicker
//
//  Created by Nap Works on 02/10/23.
//

import SwiftUI

@main
struct CustomSegmentedPickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
