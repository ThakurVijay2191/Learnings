//
//  ContentView.swift
//  CustomSegmentedPicker
//
//  Created by Nap Works on 02/10/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
